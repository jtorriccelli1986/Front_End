class Heplers{
	constructor(){}
	static altas(valor){
		return valor.upperCase();
	}
}