let alumno=new Persona("Juan Carlos","Ramos");

alumno.saludar();
alumno.nombreCompleto();

let usuario={
	nombre:"JC",
	apellido:"RT",
	edad:20,
	nombreCompleto:function(){
		//console.log(this);
		let referencia=this;
		//console.log(this.nombre+" "+this.apellido)

		function calcular(){
			console.log(referencia)
		}
		calcular();
	}
}

//usuario.nombreCompleto();



usuario.tarea=alert;

function alert(){
	console.log(this.nombre);
}

usuario.tarea();

alert()



function getEdad(anionacimiento,nombre){
	console.log(anionacimiento);
	console.log(this.edad)
}

//getEdad.apply(contexto,parametro1,paremetro2)



getEdad.call(usuario,1920,"juancarlos");
getEdad.apply(usuario,[1920,"juancarlos"])
//getEdad.call(usuario,[1920])


/*let ayuda=new Heplers();
ayuda.altas()
*/

/*let nombre_altas=Heplers.altas("juancarlos");
let obj=new Math()
obj.max();
*/
Math.max()
