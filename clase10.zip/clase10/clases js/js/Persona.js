class Persona{
	constructor(nombre,apellido){
		this.nombre=nombre;
		this.apellido=apellido;
	}
	saludar(){
		console.log("hola desde un metodo de una clase");
	}
	nombreCompleto(){
		console.log(this.nombre+ " " +this.apellido);
	}

}





