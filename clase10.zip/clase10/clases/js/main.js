$(".nav-site li").click(function(){
	console.log("click");
	$(".nav-site li").removeClass("activado");
	$(this).addClass("activado");
})

$(".head-acordion").click(function(){
	$(this).toggleClass("visto")
	//$(".contenido").show();
	/*$(".contenido").hide();
	$(this).parent().find(".contenido").show();*/
	//$(".contenido").hide();
	
	$(this).parent().find(".contenido").slideToggle();
	//$(this).parent().find(".contenido").toggle();
	//$(this).parent().find(".contenido").fadeIn();

})