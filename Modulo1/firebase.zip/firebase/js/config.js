  // Your web app's Firebase configuration
	  var firebaseConfig = {
	    apiKey: "AIzaSyC1EtL08F2ysUk7JnAm7ihyhclODrDKU_k",
	    authDomain: "chat-clase-2d353.firebaseapp.com",
	    databaseURL: "https://chat-clase-2d353.firebaseio.com",
	    projectId: "chat-clase-2d353",
	    storageBucket: "",
	    messagingSenderId: "1018841653135",
	    appId: "1:1018841653135:web:8ca54b845a2b7d97"
	  };
	  // Initialize Firebase
	  firebase.initializeApp(firebaseConfig);