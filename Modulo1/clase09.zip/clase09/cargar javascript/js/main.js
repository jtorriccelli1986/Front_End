//$(".item").click();
$(window).load(function(){
let elemento=document.getElementById('title');
console.log(elemento);
elemento.addEventListener("click",()=>{})
})

$(document).ready(function(){
	
})

