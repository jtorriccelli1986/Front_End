let estado=true;


if(4>3){
	// esta condicional
}
else{
	// se ejecuta en caso el
	// valor de la condicion sea falso
}


function validarUsuario(user,password){
	// validacion

	return true;
}

let validacion=validarUsuario("JC",123)

if(validacion){
	// el usuario es correcto
}
else{
	// el usuario es incorrecto
}

let n1=10;
let n2=20;
let n3=30;

if(n1>n2){
  // 
  if(n1>n3){
  	// n1 es mayor de los tres
  }
  else{

  	// n3 es el mayor de los tre
  }
}
else{
   if(n2>n3){
   	// n2 es el mayor
   }
   else{
   	// n3 es el mayor de los3
   }
}


     
if(n1>n2 && n1>n3){
   // el n1 es el mayor
}
else{
	if(n2>n1 && n2>n3){
		//n2 es el mayor
	}
	else{
		//n3 el mayor
	}
}

0-10
11-20
20-30



if(num<10){
	// primer rango
}
else{
	if(num<20){
		//segundo rango
	}
	else{
		if(num<30){
			// tercer rango
		}
	}
}


if(num<10){

}
else if(num<20){

}
else if(num<30){


}
else{
	// no existe rango para ti
}





// if ternario
let estado=(4>3)?"uno":"dos";






for (var i=0; i <10; i++) {
	console.log(i);

}

num1=6;
while(num1<5){
	//codigo a ejecutar
	num1++
}




num2=10
do {
 // ejecuta 1 vez
}while(num2<5)


switch("A"){

	case "A":
		console.log("rango A");
		break;
	case "B":
		console.log("RAngo B");
		break;
	default:
	 console.log("valor no permitido")
	 break;

}