if(localStorage.estadoLogin=="true"){
			window.location="./listado.html"

}



let error=document.getElementById("msg-error-login");


let elemento=document.getElementById('btn-acceder');
elemento.addEventListener("click",(e)=>{
	/*e.preventDefault();*/
	/*alert("hizo click")*/
	/*event.preventDefault();*/
	/*
	let usuario=document.getElementById("inp-usuario");
	let password=document.getElementById("inp-password");

	let valor_usuario=usuario.value;
	let valor_password=password.value;
	*/

	let usuario=document.getElementById("inp-usuario").value;
	let password=document.getElementById("inp-password").value;

	/*
	console.log(usuario)
	console.log(password)*/
	let estado_login=validarUsuario(usuario,password);

	if(estado_login==1){
		//
		//alert("datos correctos");
		error.classList.add("hide");
		window.location="./listado.html"

		registarUsuarioTemporal(usuario);

	}
	else if(estado_login==2){
			error.classList.remove("hide");
			error.innerHTML="Los datos ingresados son incorrectos";
	}
	else{
		//alert("datos incorrectos");
	
	}


})


function validarUsuario(valor1,valor2){
	

	let estado=0;
	let sin_espacios_1=valor1.trim();


	if(valor1.trim()!=""){
		if(valor2.trim()!=""){
			error.classList.add("hide");
			// los valores estan ingresados
			if(valor1=="admin" && valor2==123){
					estado=1;
				}
				else{
					estado=2;
				}	

		}	
		else{
			error.classList.remove("hide");
			error.innerHTML="password esta en blanco";
			//alert("password esta en blanco")
		}
	}	
	else{
		error.classList.remove("hide");
		error.innerHTML="usuario esta en blanco";
		//alert("usuario esta en blanco")
	}


	

	return estado;

}

function registarUsuarioTemporal(nombre){
	let hora=new Date();
	localStorage.estadoLogin=true;
		localStorage.nombreusuario=nombre;
	localStorage.hora=hora.getHours();
	/*sessionStorage.estadoLogin=true;*/
}