let elemento=document.getElementById('btn-listar');
document.getElementById("bienvenida").innerHTML="Binvenido: "+localStorage.nombreusuario
elemento.addEventListener("click",()=>{
	/*let data={
		usuario:"Juan",
		password:123
	}*/

	let xhr=new XMLHttpRequest;
	
	let url="https://jsonplaceholder.typicode.com/users";

	xhr.open("POST",url,true);
	

	xhr.send(null);
	
	xhr.onreadystatechange=()=>{
		if(xhr.status==200){
			if(xhr.readyState==4){
				console.log(xhr)
				let datos=JSON.parse(xhr.responseText);
		
				let limite=datos.length;
				let temp="";
				for(var i=0;i<limite;i++){
					/*temp=temp+'<li>'
					+'<span class="h2">' +datos[i].name+ '</span>'
					+'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>'
				+'</li>';*/
				temp=temp+ `<li>
								<span class="h2">${datos[i].name}</span>
								<p>${datos[i].email}</p>
							</li>`
					//console.log(datos[i].name + " " +datos[i].email )
				}	

				document.getElementById("listado").innerHTML=temp;

			}
		

		}
		else{

		}

	}

	/*xhr.onreadystatechange=()=>{
		if (xhr.status==200){
			//console.log(xhr.getAllResponseHeaders())
				/*console.log(xhr.readyState);
				console.log(xhr.responseText);
				console.log(JSON.parse(xhr.responseText));
				document.getElementById('texto').innerHTML=xhr.responseText
*/		
	//resolve(xhr.responseText);
	/*	}	
	}*/
	



})

document.getElementById("btn-cerrar").addEventListener("click",cerrarUsuarioTemporal);
function cerrarUsuarioTemporal(){

	localStorage.estadoLogin=false;
	console.log(localStorage.estadoLogin);
	window.location="./index.html";
}
