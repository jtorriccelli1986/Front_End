//console.log("imprimir desde javascript");
// palabra reservada

/*var dato;
var dat2;
var dato4;
var dato3;
*/
"use strict";

var nombre;
nombre="Juan Carlos"; // asigando un valor a la variable

//dato // "Juan Carlos"

var dato2;
dato2=30;
dato2="HOLA";

var dato3="dijo:\"Hola!\" ";
var dato4;
dato4=5

console.log(dato4);

var num1="10";
var num2="20";
var suma=num1-num2;
console.log(suma);

console.log(Math.PI);
Math.max(15,15,20,14);
Math.min(1,2,15,12);
Math.round(10.9);
Math.ceil(10.1) // 11
Math.floor(10.9) // 10

var aleatorio=Math.random()*10;
var aleatorio_entero=Math.round(aleatorio);
console.log(aleatorio_entero);

var nombre="Diego";
console.log("Diego");
console.log(nombre.length);

var nombre2=new String("Diego");
console.log(nombre2)
console.log(nombre2.length);

console.log(nombre.indexOf("o"))

console.log(nombre.toUpperCase())
var nombre3="     juan  v asdasd    as    ";

console.log(nombre3.trim())

/* 
Let
const
*/

let usuario_nombre="JC";
let usuario_email="jtorr@gmail.com";


//let usuario_nombre="DIEGO";


const TIPO_CAMBIO=3.25;

var estado;
estado=false;
estado=true;

// false
estado=0;
estado=NaN;
estado=null;

// true
estado="213"
//fecha
var fecha="10/10/2015";
var fecha_actual=new Date();
console.log(fecha);
console.log(fecha_actual);

// año actual
console.log(fecha_actual.getFullYear());// año actual
console.log(fecha_actual.getMonth());//| Mes actual
console.log(fecha_actual.getDate());// |dia del mes actual


console.log(fecha_actual.getDay());// dia actual de la semana

console.log(fecha_actual.getHours());//| año actual
console.log(fecha_actual.getMinutes());// |año actual
console.log(fecha_actual.getSeconds());//| año actual




// arreglo
 //var nombre=""
 //var codigo=""
 //var turno="Noche"

 let lista=["Juan Carlos","Juan Carlos","123asv",,"Juan Carlos","123asv","123asv","Noche",12,true,[10,10,10]];

let cantidad_elementos=lista.length; // 20
let indice_last=cantidad_elementos-1;
console.log(lista[indice_last]);

/*console.log(lista);
let notas=lista[5]
console.log(notas[0])*/


// variable objeto
var arreglo_persona=["jc","rt","noche"]

var persona1={
	nombre:"Jc",
	apellido:"Rt",
	turno:"noche",
	notas:[19,12,15]
}

console.log(persona.turno)
console.log(persona["turno"]);
console.log(persona.notas[0])
console.log(persona.notas[1])
console.log(persona.notas[2])


var persona2={
	nombre:"Diego",
	apellido:"Rt",
	turno:"noche",
	notas:[19,12,15]
}
var persona3={
	nombre:"Martin",
	apellido:"Rt",
	turno:"noche",
	notas:[19,12,15]
}


let listado_persona=[persona1,persona2,persona3]
let seleccionado=listado_persona[0]
	seleccionado.nombre;


const lista=[1,2,3];
lista=[1,2,3,4,5];


listado=[]

listado.push(1) // agrega elementos al final del arreglo
//[1]

listado.push(2) /// devuelve la cantidad elementos actuales
//[1,2]

listado.pop(); // devuelve el elemento eliminado

listado.unshift(3) // agrega un elemento al inicio
//[3,1]
listado.shift() // elimina el primer elemento de arreglo















