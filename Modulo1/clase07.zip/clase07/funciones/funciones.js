suma(5,8);
suma(15,8);
suma(55,8);
restar(10);


// declaracion de funcion
function suma(valor1,valor2){
	console.log(valor1+valor2);
}
// asignacion de funcion
let restar=function(valor1,valor2){
	console.log(valor1-valor2);
}


function calcularIGV(valor1){
	return valor1*0.18;
}

let igv=calcularIGV(100);

let division=(valor)=>{
	return valor*0.18
}


let division = (valor) =>{
	return valor*0.18;
}









